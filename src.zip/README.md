Element structure
- Category
- Block (contained in category)
- Theme (contained in block)
- Question (contained in theme)
- Answer (contained in theme)
- QaMapping (combines questions with answers)

Listening port: 8081
Localhost test URL: http://localhost:8081/
