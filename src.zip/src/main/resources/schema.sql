CREATE DATABASE IF NOT EXISTS opotromatic;
USE opotromatic;
